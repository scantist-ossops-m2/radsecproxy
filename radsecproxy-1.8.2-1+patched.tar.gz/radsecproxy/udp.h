/* Copyright (c) 2008, UNINETT AS */
/* See LICENSE for licensing information. */

const struct protodefs *udpinit(uint8_t h);

/* Local Variables: */
/* c-file-style: "stroustrup" */
/* End: */
