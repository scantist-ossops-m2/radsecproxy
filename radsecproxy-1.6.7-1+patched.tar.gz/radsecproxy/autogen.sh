#!/bin/sh
touch NEWS
autoreconf --force --install
